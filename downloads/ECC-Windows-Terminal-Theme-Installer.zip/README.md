# ECC Windows Terminal colour-scheme installer

Runs with PowerShell 7+ on Windows. It appends schemes from the included JSON file to the existing Windows Terminal `settings.json`, preserving unrelated configuration and JSONC comments. It does **not** set a theme as active.

## Usage

```powershell
# Inspect the proposed operation, without writing anything
.\Install-ECCWindowsTerminalThemes.ps1 -WhatIf

# Create a backup and install the missing schemes
.\Install-ECCWindowsTerminalThemes.ps1

# Select a particular settings file (useful if Stable and Preview are installed)
.\Install-ECCWindowsTerminalThemes.ps1 -SettingsPath "$env:LOCALAPPDATA\Packages\Microsoft.WindowsTerminal_8wekyb3d8bbwe\LocalState\settings.json"
```

PowerShell's execution policy must permit the script. Do not disable your security policy globally just to run it. If the file has a downloaded-file zone marker and you trust its source, `Unblock-File` may be appropriate.

## Safety guarantees

- Uses a unique timestamped copy at `settings.json.backup-YYYYMMDD-HHMMSS-XXXXXX.json` before writing.
- Parses source and target JSON (including Windows Terminal's JSONC comments and trailing commas), then validates the merged result.
- Preserves comments, profiles, keybindings, and other settings by inserting only under `schemes`.
- Skips schemes with names that already exist (case-insensitive); safe to run again.
- If multiple Windows Terminal settings are found, stops and requires `-SettingsPath`.
- Uses a temporary file in the same directory and .NET `File.Replace` for atomic replacement. If replacement fails, the backup remains.
- Does not need M365, internet access, administrator privilege, or TidyLog.

## Restore

Close Windows Terminal settings editing windows and restore the saved backup manually:

```powershell
Copy-Item -LiteralPath 'FULL_PATH_TO_BACKUP' -Destination 'FULL_PATH_TO_SETTINGS_JSON' -Force
```

## Compatibility

Tested for JSON syntax and packaging in the build environment; the PowerShell script itself has **not** been executed on Windows Terminal. Use `-WhatIf` before running it. It requires PowerShell 7+ and Windows Terminal's JSON `schemes` array format. When inserting into existing JSONC, unusual custom formatting may cause the merge to fail validation, in which case settings are not written.
